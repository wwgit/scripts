
from distutils.core import setup

setup(
 name='mytest',
 version='1.0.0',
 author="WangRM",
 author_email="wangruiming@gw.com.cn",
 url="http://127.0.0.1:8080/educationma/search",
 py_modules=['traceback','redis2redis','yaml','redis'],
 )
 